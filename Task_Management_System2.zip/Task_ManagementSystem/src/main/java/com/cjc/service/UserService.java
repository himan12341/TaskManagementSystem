package com.cjc.service;

import com.cjc.demo.User;

public interface UserService 
{
    void registerUser(User user);

	User getUserByUsername(String username);

}

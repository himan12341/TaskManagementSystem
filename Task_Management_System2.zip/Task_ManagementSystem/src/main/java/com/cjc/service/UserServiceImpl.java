package com.cjc.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cjc.demo.User;
import com.cjc.repository.UserRepository;

public class UserServiceImpl implements UserService
{
	private final UserRepository userRepository;

    @Autowired
    public UserServiceImpl(UserRepository userRepository) 
    {
        this.userRepository = userRepository;
    }

	@Override
	public void registerUser(User user) 
	{
		userRepository.save(user);
	}

	@Override
	public User getUserByUsername(String username)
	{	
		return null;
	}
}
